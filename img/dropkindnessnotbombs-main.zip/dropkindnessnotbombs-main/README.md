# dropkindnessnotbombs
Drop kindness not bombs
